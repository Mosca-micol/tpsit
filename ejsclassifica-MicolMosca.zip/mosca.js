let fs = require('fs')

function addElementToJSON(jsonData, element) {
  jsonData.push(element)
}

function writeFileJSON(file, dataJSON) {
  fs.writeFile(file, JSON.stringify(dataJSON), (err) => {
    if (err) {
      throw err;
    } else
      console.log('i dati li ho scritti nel file person.json');
  })
}

module.exports = { addElementToJSON: addElementToJSON, writeFileJSON: writeFileJSON }