const express = require('express');
const ejs = require('ejs');
const bodyParser = require('body-parser');
const fs = require('fs');
let data = require('./data/person.json');

const app = express();

//imposta i template ejs
app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extend: false }));
app.use(express.static(__dirname + '/public'));

//data
let page_date = new Date();


app.get('/', (req, res) => {
  res.render('table', { page_date: page_date });
  res.render('table', { jsonData: data });
});

app.get('/table', (req, res) => {
  res.render('table', { jsonData: data });
});

app.get('/json', function(req, res) {
  res.sendFile(__dirname + "/data/person.json")
})

app.post('/scrivi', function(req, res) {
  let person = {
    nome: req.nome,
    messaggio: req.messaggio,
    nickname: req.nickname,
    colore: req.colore,
    font: req.font
  }
  console.log(person)
  let jsonData = JSON.stringify(person, null, 2)
  fs.writeFile('./data/person.json', jsonData, (err) => {
    if (err) {
      throw err;
    }
    console.log('I dati li ho scritti nel file person.json');

  })
});


app.listen(3000, () => {
  console.log('App is running on port 3000')
});
